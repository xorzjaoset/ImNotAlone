package ho.dto;

public class MyPageDTO {

}
